/* red-black tree description */

typedef unsigned char NodeColor;

#define BLACK (0)
#define RED (1)

// typedef enum { BLACK, RED } NodeColor;
